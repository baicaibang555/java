/** 
 * @Project     DN-springmvc 
 * @File        package-info.java 
 * @Package     com.dongnao.jack.service.impl 
 * @Version     V1.0 
 * @Date        2016��12��23�� ����8:57:54 
 * @Author      dongnao.jack 
 */

/** 
 * @Description TODO 
 * @ClassName   package-info 
 * @Date        2016��12��23�� ����8:57:54 
 * @Author      dongnao.jack 
 */

package com.dongnao.jack.service.impl;