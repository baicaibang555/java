package com.dongnao.jack.service;

public interface JackService {
    
    String query(String param);
    
    String insert(String param);
    
    String update(String param);
}
